package com.affinipay.exceptions;

public class InvalidTwelveHourClockTimeFormatException extends Exception{
    public InvalidTwelveHourClockTimeFormatException(String message) {
        super(message);
    }
}
